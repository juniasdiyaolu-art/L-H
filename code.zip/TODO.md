# L&H Collective — delivery outcomes

## Brand shell and responsive foundation

- [ ] The site uses a clean white/cream background, black text, one warm accent color, elegant serif headings, clean sans-serif body text, smooth lightweight transitions, mobile-first responsive layout, and lazy-loaded images.
- [ ] Every route has sticky navigation with the L&H Collective wordmark, Shop, Collections, About, Contact, search, and wishlist controls; mobile navigation opens and closes correctly.
- [ ] Every route includes the announcement bar, footer with links/contact/social/delivery information, floating WhatsApp button with a gentle pulse, and a back-to-top affordance where appropriate.

## Home experience

- [ ] Home includes a full-width lifestyle hero with punchy sales copy, a subline about effortless affordable style delivered to the door, “Shop New Arrivals”, and “Order on WhatsApp” CTAs.
- [ ] Home includes category tiles for Clothing, Bags, Accessories, New Arrivals, and Sale; featured products; a Best Sellers row; a Shop the Look section; benefits for quality, fast local delivery, easy WhatsApp ordering, and affordable prices; customer reviews; an Instagram-style photo grid; and email/WhatsApp signup copy.

## Catalog and product data

- [ ] Product data is loaded from one easy-to-edit file and includes 12 sample products with placeholder fashion imagery, names, prices, descriptions, sizes, colors, category, stock status, and merchandising metadata.
- [ ] Shop presents 50+ product cards from the editable catalog demonstration, each with image, name, price, WhatsApp order action, wishlist heart, sold-out badge when applicable, and notify-on-WhatsApp action for unavailable items.
- [ ] Shop provides working search, category filter, price range filter, size filter, color filter, and newest/price low-high/price high-low sorting.
- [ ] Product detail provides image gallery with zoom behavior, size and color selectors, size guide popup, stock status, description, urgency copy, recommendations, and exact WhatsApp message format: “Hi! I'd like to order [product name], size [size], color [color]. Price: [price].”

## WhatsApp ordering and wishlist

- [ ] Floating WhatsApp opens a chat with the configured placeholder number and a prefilled welcome message.
- [ ] Customers can save/remove products in a browser-persisted wishlist and open a wishlist page.
- [ ] Customers can add several products to an order list, adjust/remove items, and send the complete list to WhatsApp in one message.
- [ ] The announcement bar reads “Free delivery on orders over [amount] | New arrivals every week”, with the amount stored in one easy-to-edit constant.

## Brand pages and accessibility

- [ ] Collections/Lookbook presents styled outfit sets with Shop This Look links.
- [ ] About explains the story of Lydia and Hannah and the brand values.
- [ ] Contact includes WhatsApp, Instagram, email, location, and a simple contact form that gives the user a useful next step.
- [ ] Delivery & Returns explains local delivery expectations and return guidance.
- [ ] The 404 route is friendly, linked back to shopping, and does not break the shell.
- [ ] Buttons, links, controls, labels, focus states, alt text, and reduced-motion behavior are accessible and functional.

## Stylist and SEO

- [ ] The AI Stylist chat widget collects occasion, budget, and style and returns outfit suggestions from the product list with WhatsApp order links.
- [ ] Public routes have descriptive titles, descriptions, heading hierarchy, alt text, route manifest entries, sitemap, robots file, and baseline Open Graph/Twitter metadata.
- [ ] The codebase passes TypeScript checking and builds as a static Vite site.
