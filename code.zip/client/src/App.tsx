import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from "react";
import {
  ArrowDownRight,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Heart,
  Instagram,
  Mail,
  MapPin,
  Menu,
  MessageCircle,
  Minus,
  Phone,
  Plus,
  Search,
  Send,
  Shirt,
  SlidersHorizontal,
  ShoppingBag,
  Sparkles,
  Star,
  Truck,
  X,
} from "lucide-react";
import { Link, Route, Switch, useLocation } from "wouter";
import { catalogProducts, getProduct, sampleProducts, type Product } from "./data/products";

const WHATSAPP_NUMBER = "2348000000000"; // Replace with the brand's real WhatsApp number.
const FREE_DELIVERY_THRESHOLD = "₦50,000";
const WHATSAPP_LABEL = "+234 800 000 0000";

type OrderLine = {
  productId: string;
  size: string;
  color: string;
  quantity: number;
};

type SharedProps = {
  wishlist: string[];
  toggleWishlist: (productId: string) => void;
  orderList: OrderLine[];
  addToOrder: (product: Product, size?: string, color?: string) => void;
  removeFromOrder: (index: number) => void;
  openOrderList: () => void;
  openStylist: () => void;
};

const money = (value: number) => `₦${value.toLocaleString("en-NG")}`;
const whatsappLink = (message: string) => `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
const productMessage = (product: Product, size = product.sizes[0], color = product.colors[0]) =>
  `Hi! I'd like to order ${product.name}, size ${size}, color ${color}. Price: ${money(product.price)}.`;

function usePageMeta(title: string, description: string) {
  useEffect(() => {
    document.title = title;
    const meta = document.querySelector('meta[name="description"]');
    if (meta) meta.setAttribute("content", description);

    [
      ["og:title", title],
      ["og:description", description],
      ["twitter:title", title],
      ["twitter:description", description],
    ].forEach(([property, content]) => {
      const tag = document.querySelector(`meta[property="${property}"], meta[name="${property}"]`);
      if (tag) tag.setAttribute("content", content);
    });
  }, [title, description]);
}

function Reveal({ children, className = "" }: { children: ReactNode; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const node = ref.current;
    if (!node || !("IntersectionObserver" in window)) return;
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        node.classList.add("is-visible");
        observer.disconnect();
      }
    }, { threshold: 0.12 });
    observer.observe(node);
    return () => observer.disconnect();
  }, []);
  return <div ref={ref} className={`reveal ${className}`}>{children}</div>;
}

function BrandMark() {
  return (
    <Link href="/" className="brand-mark" aria-label="L&H Collective home">
      <span className="brand-monogram">L<span>&amp;</span>H</span>
      <span className="brand-name">Collective</span>
    </Link>
  );
}

function ProductCard({ product, isWishlisted, onWishlist, onAdd, onOrder }: {
  product: Product;
  isWishlisted: boolean;
  onWishlist: () => void;
  onAdd: () => void;
  onOrder: () => void;
}) {
  return (
    <article className="product-card">
      <div className="product-image-wrap">
        <Link href={`/product/${product.id}`} className="product-image-link" aria-label={`View ${product.name}`}>
          <img src={product.image} alt={product.alt} loading="lazy" className="product-image" />
        </Link>
        <div className="product-badges">
          {product.isNew && <span className="badge badge-dark">New in</span>}
          {product.isSale && <span className="badge badge-sale">Sale</span>}
          {product.stock === 0 && <span className="badge badge-light">Sold out</span>}
        </div>
        <button className={`heart-button ${isWishlisted ? "is-active" : ""}`} onClick={onWishlist} aria-label={isWishlisted ? `Remove ${product.name} from wishlist` : `Add ${product.name} to wishlist`}>
          <Heart size={17} fill={isWishlisted ? "currentColor" : "none"} />
        </button>
      </div>
      <div className="product-card-copy">
        <div className="product-meta-row">
          <span className="eyebrow">{product.category}</span>
          {product.stock > 0 && product.stock <= 4 && <span className="stock-note">Only a few left</span>}
        </div>
        <Link href={`/product/${product.id}`} className="product-name">{product.name}</Link>
        <p className="product-description">{product.description}</p>
        <div className="product-footer-row">
          <span className="product-price">{money(product.price)}</span>
          <button className="text-action" onClick={onAdd} disabled={product.stock === 0}>
            {product.stock === 0 ? "Unavailable" : "Add to list"} <Plus size={14} />
          </button>
        </div>
        <a className={`card-order-link ${product.stock === 0 ? "is-muted" : ""}`} href={whatsappLink(product.stock === 0 ? `Hi! Please notify me when ${product.name} is back in stock.` : productMessage(product))} target="_blank" rel="noreferrer" onClick={onOrder}>
          {product.stock === 0 ? "Notify me on WhatsApp" : "Order on WhatsApp"} <ArrowUp size={14} />
        </a>
      </div>
    </article>
  );
}

function Shell({ children, wishlist, orderCount, openOrderList, openStylist }: { children: ReactNode; wishlist: string[]; orderCount: number; openOrderList: () => void; openStylist: () => void }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [showTop, setShowTop] = useState(false);
  const [, setLocation] = useLocation();

  useEffect(() => {
    const handleScroll = () => setShowTop(window.scrollY > 550);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const submitSearch = (event: FormEvent) => {
    event.preventDefault();
    setMobileOpen(false);
    setSearchOpen(false);
    setLocation(`/shop?search=${encodeURIComponent(searchTerm)}`);
  };

  const closeMobile = () => setMobileOpen(false);

  return (
    <div className="site-shell">
      <div className="announcement-bar">
        <span>Free delivery on orders over {FREE_DELIVERY_THRESHOLD}</span>
        <span className="announcement-divider">•</span>
        <span>New arrivals every week</span>
      </div>
      <header className="site-header">
        <div className="header-inner">
          <button className="mobile-menu-button icon-button" onClick={() => setMobileOpen(!mobileOpen)} aria-label={mobileOpen ? "Close menu" : "Open menu"}>
            {mobileOpen ? <X size={21} /> : <Menu size={21} />}
          </button>
          <BrandMark />
          <nav className="desktop-nav" aria-label="Main navigation">
            <Link href="/shop">Shop</Link>
            <Link href="/collections">Collections</Link>
            <Link href="/about">About</Link>
            <Link href="/contact">Contact</Link>
          </nav>
          <div className="header-actions">
            <button className="icon-button" onClick={() => setSearchOpen(!searchOpen)} aria-label="Search the shop"><Search size={19} /></button>
            <Link href="/wishlist" className="header-icon-link" aria-label={`Wishlist with ${wishlist.length} items`}><Heart size={19} /><span className="header-count">{wishlist.length}</span></Link>
            <button className="bag-button" onClick={openOrderList} aria-label={`Order list with ${orderCount} items`}><ShoppingBag size={19} /><span>{orderCount}</span></button>
          </div>
        </div>
        {searchOpen && (
          <form className="search-bar" onSubmit={submitSearch}>
            <Search size={17} />
            <input autoFocus value={searchTerm} onChange={(event) => setSearchTerm(event.target.value)} placeholder="Search dresses, bags, accessories..." aria-label="Search products" />
            <button type="submit" className="search-submit">Search</button>
          </form>
        )}
      </header>
      {mobileOpen && (
        <div className="mobile-nav-panel">
          <Link href="/shop" onClick={closeMobile}>Shop <ArrowRight size={15} /></Link>
          <Link href="/collections" onClick={closeMobile}>Collections <ArrowRight size={15} /></Link>
          <Link href="/about" onClick={closeMobile}>About <ArrowRight size={15} /></Link>
          <Link href="/contact" onClick={closeMobile}>Contact <ArrowRight size={15} /></Link>
          <button onClick={() => { openStylist(); closeMobile(); }}>Find my look <Sparkles size={15} /></button>
          <form className="mobile-search-form" onSubmit={submitSearch}>
            <Search size={16} />
            <input value={searchTerm} onChange={(event) => setSearchTerm(event.target.value)} placeholder="Search the edit" aria-label="Search products" />
            <button type="submit" aria-label="Submit search"><ArrowRight size={16} /></button>
          </form>
        </div>
      )}
      <main>{children}</main>
      <Footer />
      <a className="floating-whatsapp" href={whatsappLink("Hi L&H Collective! I have a question about your pieces.")} target="_blank" rel="noreferrer" aria-label="Chat with L&H Collective on WhatsApp">
        <MessageCircle size={21} /><span>Chat with us</span>
      </a>
      {showTop && <button className="back-to-top" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} aria-label="Back to top"><ArrowUp size={17} /></button>}
    </div>
  );
}

function Footer() {
  return (
    <footer className="site-footer">
      <div className="footer-main container">
        <div className="footer-brand-column">
          <BrandMark />
          <p>Easy pieces. Big outfit energy.</p>
          <a href={whatsappLink("Hi L&H Collective! I would like to shop your latest drops.")} target="_blank" rel="noreferrer" className="footer-whatsapp"><MessageCircle size={15} /> {WHATSAPP_LABEL}</a>
        </div>
        <div className="footer-column"><p className="eyebrow">Explore</p><Link href="/shop">Shop all</Link><Link href="/collections">Collections</Link><Link href="/wishlist">Wishlist</Link></div>
        <div className="footer-column"><p className="eyebrow">Need to know</p><Link href="/about">Our story</Link><Link href="/delivery">Delivery &amp; returns</Link><Link href="/contact">Contact us</Link></div>
        <div className="footer-column"><p className="eyebrow">Follow along</p><a href="https://instagram.com" target="_blank" rel="noreferrer"><Instagram size={15} /> @lhcollective</a><a href="mailto:hello@lhcollective.ng"><Mail size={15} /> hello@lhcollective.ng</a><span><MapPin size={15} /> Lagos, Nigeria</span></div>
      </div>
      <div className="footer-bottom container"><span>© {new Date().getFullYear()} Lydia &amp; Hannah Collective</span><span>Made for your next good outfit.</span></div>
    </footer>
  );
}

function HomePage(props: SharedProps) {
  usePageMeta("L&H Collective | Effortless Nigerian style", "Shop casual clothing, bags, and accessories from L&H Collective. Easy WhatsApp ordering and local delivery across Nigeria.");
  const categories = [
    { label: "Clothing", image: "/assets/editorial-neutral.jpg", note: "Everyday, elevated" },
    { label: "Bags", image: "/assets/bag-neutral.jpg", note: "Carry a little joy" },
    { label: "Accessories", image: "/assets/lookbook-neutral.jpg", note: "The finishing touch" },
    { label: "New arrivals", image: "/assets/hero-terracotta.jpg", note: "Just landed" },
    { label: "Sale", image: "https://images.unsplash.com/photo-1523381294911-8d3cead13475?auto=format&fit=crop&w=900&q=82", note: "Good pieces, better prices" },
  ];
  const bestSellers = sampleProducts.filter((product) => product.isBestSeller);

  return (
    <>
      <section className="hero-section">
        <div className="hero-image-pane"><img src="/assets/hero-terracotta.jpg" alt="Terracotta fashion editorial for L&H Collective" /></div>
        <div className="hero-copy-pane">
          <p className="eyebrow">Lagos / Everyday dressing</p>
          <h1>Dress like<br /><em>you mean it.</em></h1>
          <p className="hero-subtitle">Effortless, affordable style for the life you are actually living — delivered to your door.</p>
          <div className="hero-actions"><Link href="/shop" className="button button-dark">Shop new arrivals <ArrowDownRight size={17} /></Link><a href={whatsappLink("Hi L&H Collective! I am ready to shop your new arrivals.")} className="button button-outline" target="_blank" rel="noreferrer">Order on WhatsApp <MessageCircle size={17} /></a></div>
          <div className="hero-note"><span className="hero-note-line" /> <span>New looks, every week</span></div>
        </div>
      </section>

      <Reveal className="container section-block category-section">
        <SectionHeading eyebrow="Make it yours" title="A little something for every mood." actionLabel="Shop everything" actionHref="/shop" />
        <div className="category-grid">{categories.map((category) => <Link href={`/shop?category=${encodeURIComponent(category.label)}`} className="category-card" key={category.label}><img src={category.image} alt={category.label} loading="lazy" /><div className="category-overlay"><span>{category.note}</span><strong>{category.label}</strong><ArrowUp size={18} /></div></Link>)}</div>
      </Reveal>

      <Reveal className="section-block soft-section"><div className="container"><SectionHeading eyebrow="The edit" title="Pieces that pull their weight." actionLabel="Shop the edit" actionHref="/shop" /><div className="product-grid product-grid-four">{sampleProducts.slice(0, 4).map((product) => <ProductCard key={product.id} product={product} isWishlisted={props.wishlist.includes(product.id)} onWishlist={() => props.toggleWishlist(product.id)} onAdd={() => props.addToOrder(product)} onOrder={() => undefined} />)}</div></div></Reveal>

      <Reveal className="container section-block best-seller-block"><div className="split-heading"><div><p className="eyebrow">Most loved</p><h2>Best sellers,<br /><em>no overthinking.</em></h2></div><p className="section-intro">The pieces our community keeps coming back for. Easy to style, easy to wear, and always ready for a compliment.</p></div><div className="horizontal-product-rail">{bestSellers.map((product) => <div className="rail-card" key={product.id}><img src={product.image} alt={product.alt} loading="lazy" /><div><p className="eyebrow">{product.category}</p><Link href={`/product/${product.id}`}>{product.name}</Link><strong>{money(product.price)}</strong></div></div>)}</div></Reveal>

      <Reveal className="lookbook-section section-block"><div className="container lookbook-layout"><div className="lookbook-image"><img src="/assets/lookbook-neutral.jpg" alt="Neutral tonal outfit for the L&H Collective lookbook" loading="lazy" /><span className="image-caption">Look 01 / Soft structure</span></div><div className="lookbook-copy"><p className="eyebrow">Shop the look</p><h2>Soft structure.<br /><em>Strong energy.</em></h2><p>Meet the outfit formula that keeps your calendar and your closet on speaking terms: a fluid layer, one confident accessory, and somewhere good to go.</p><Link href="/collections" className="text-link">Explore the lookbook <ArrowRight size={15} /></Link></div></div></Reveal>

      <Reveal className="container section-block values-section"><div className="split-heading"><div><p className="eyebrow">Why L&amp;H</p><h2>Good style should<br /><em>feel easy.</em></h2></div><p className="section-intro">No gatekeeping, no complicated checkout. Just good pieces, clear prices, and a real person on the other side of WhatsApp.</p></div><div className="value-grid"><ValueItem number="01" icon={<Star size={18} />} title="Quality pieces" text="Thoughtful fabrics, wearable shapes, and details that hold up to repeat wears." /><ValueItem number="02" icon={<Truck size={18} />} title="Fast local delivery" text="We keep getting dressed simple, with delivery support across Nigeria." /><ValueItem number="03" icon={<MessageCircle size={18} />} title="Easy WhatsApp ordering" text="Ask a question, share your size, and place your order in a few taps." /><ValueItem number="04" icon={<Heart size={18} />} title="Affordable prices" text="The kind of wardrobe refresh that does not require a wardrobe rethink." /></div></Reveal>

      <ReviewsSection />

      <Reveal className="container section-block social-section"><SectionHeading eyebrow="On the feed" title="Come for the outfit energy." actionLabel="Follow @lhcollective" actionHref="https://instagram.com" /><div className="social-grid"><img src="/assets/editorial-neutral.jpg" alt="L&H Collective style detail" loading="lazy" /><img src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=800&q=82" alt="Neutral outfit detail" loading="lazy" /><img src="/assets/bag-neutral.jpg" alt="Neutral everyday bag" loading="lazy" /><img src="https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=800&q=82" alt="Curated clothing rack" loading="lazy" /><img src="/assets/lookbook-neutral.jpg" alt="Soft neutral lookbook outfit" loading="lazy" /></div></Reveal>

      <Reveal className="signup-section"><div className="container signup-inner"><div><p className="eyebrow">Stay in the know</p><h2>New drops.<br /><em>Good news.</em></h2></div><div className="signup-copy"><p>Get first dibs on new arrivals, restocks, and the occasional outfit nudge. No noise, promise.</p><form className="signup-form" onSubmit={(event) => { event.preventDefault(); alert("You are on the list — see you in the next drop."); }}><input type="email" required placeholder="Your email address" aria-label="Your email address" /><button className="button button-dark" type="submit">Join the list <ArrowRight size={16} /></button></form><a href={whatsappLink("Hi L&H Collective! Please add me to the WhatsApp new drops list.")} target="_blank" rel="noreferrer" className="whatsapp-signup"><MessageCircle size={15} /> Or get drops on WhatsApp</a></div></div></Reveal>
    </>
  );
}

function SectionHeading({ eyebrow, title, actionLabel, actionHref }: { eyebrow: string; title: string; actionLabel?: string; actionHref?: string }) {
  const action = actionLabel && actionHref ? (actionHref.startsWith("http") ? <a href={actionHref} className="text-link" target="_blank" rel="noreferrer">{actionLabel} <ArrowRight size={15} /></a> : <Link href={actionHref} className="text-link">{actionLabel} <ArrowRight size={15} /></Link>) : null;
  return <div className="section-heading"><div><p className="eyebrow">{eyebrow}</p><h2>{title}</h2></div>{action}</div>;
}

function ValueItem({ number, icon, title, text }: { number: string; icon: ReactNode; title: string; text: string }) {
  return <div className="value-item"><div className="value-top"><span>{number}</span><div className="value-icon">{icon}</div></div><h3>{title}</h3><p>{text}</p></div>;
}

function ReviewsSection() {
  const [active, setActive] = useState(0);
  const reviews = [
    ["The kind of pieces that make getting ready feel like a treat again.", "Tomi, Lagos"],
    ["I sent a WhatsApp message at lunch and had my new bag by the weekend. So easy.", "Ada, Abuja"],
    ["The fit advice was actually helpful and the skirt is now in heavy rotation.", "Mariam, Ibadan"],
  ];
  return <Reveal className="review-section section-block"><div className="container review-inner"><div className="review-label"><p className="eyebrow">Good words</p><span>0{active + 1} / 03</span></div><div className="review-quote"><Star size={17} fill="currentColor" /><blockquote>“{reviews[active][0]}”</blockquote><p>{reviews[active][1]}</p><div className="review-controls"><button onClick={() => setActive((active + reviews.length - 1) % reviews.length)} aria-label="Previous review"><ChevronLeft size={17} /></button><button onClick={() => setActive((active + 1) % reviews.length)} aria-label="Next review"><ChevronRight size={17} /></button></div></div></div></Reveal>;
}

function ShopPage(props: SharedProps) {
  usePageMeta("Shop | L&H Collective", "Browse 50+ easy, affordable clothing, bags, and accessories from L&H Collective.");
  const [location] = useLocation();
  const params = new URLSearchParams(window.location.search);
  const [searchTerm, setSearchTerm] = useState(params.get("search") || "");
  const [category, setCategory] = useState(params.get("category") || "All");
  const [size, setSize] = useState("All");
  const [color, setColor] = useState("All");
  const [maxPrice, setMaxPrice] = useState(60000);
  const [sort, setSort] = useState("newest");
  const [filtersOpen, setFiltersOpen] = useState(false);
  useEffect(() => {
    const current = new URLSearchParams(location.split("?")[1] || "");
    setSearchTerm(current.get("search") || "");
    setCategory(current.get("category") || "All");
  }, [location]);

  const visibleProducts = useMemo(() => {
    const filtered = catalogProducts.filter((product) => {
      const searchMatch = `${product.name} ${product.description} ${product.tags.join(" ")}`.toLowerCase().includes(searchTerm.toLowerCase());
      const categoryMatch = category === "All" || product.category.toLowerCase() === category.toLowerCase() || (category === "New arrivals" && product.isNew) || (category === "Sale" && product.isSale);
      const sizeMatch = size === "All" || product.sizes.includes(size);
      const colorMatch = color === "All" || product.colors.includes(color);
      return searchMatch && categoryMatch && sizeMatch && colorMatch && product.price <= maxPrice;
    });
    return filtered.sort((a, b) => sort === "price-low" ? a.price - b.price : sort === "price-high" ? b.price - a.price : Number(Boolean(b.isNew)) - Number(Boolean(a.isNew)) || a.name.localeCompare(b.name));
  }, [searchTerm, category, size, color, maxPrice, sort]);

  const clearFilters = () => { setSearchTerm(""); setCategory("All"); setSize("All"); setColor("All"); setMaxPrice(60000); setSort("newest"); };

  return <div className="container page-shell"><div className="page-intro"><div><p className="eyebrow">The full edit</p><h1>Shop the good stuff.</h1></div><p>Clothes, bags, and little extras made for repeat wears, spontaneous plans, and the days in between.</p></div><div className="shop-toolbar"><button className="filter-toggle" onClick={() => setFiltersOpen(!filtersOpen)}><SlidersHorizontal size={16} /> Filters</button><span className="result-count">{visibleProducts.length} pieces</span><label className="sort-label">Sort by <select value={sort} onChange={(event) => setSort(event.target.value)}><option value="newest">Newest</option><option value="price-low">Price: low to high</option><option value="price-high">Price: high to low</option></select><ChevronDown size={14} /></label></div><div className={`shop-layout ${filtersOpen ? "filters-visible" : ""}`}><aside className="filter-panel"><div className="filter-header"><span className="eyebrow">Refine</span><button onClick={clearFilters}>Clear all</button></div><FilterGroup label="Category"><select value={category} onChange={(event) => setCategory(event.target.value)}><option>All</option><option>Clothing</option><option>Bags</option><option>Accessories</option><option>New arrivals</option><option>Sale</option></select></FilterGroup><FilterGroup label="Size"><select value={size} onChange={(event) => setSize(event.target.value)}><option>All</option>{["S", "M", "L", "XL", "One size", "37", "38", "39", "40", "41"].map((item) => <option key={item}>{item}</option>)}</select></FilterGroup><FilterGroup label="Colour"><select value={color} onChange={(event) => setColor(event.target.value)}><option>All</option>{["Sand", "Black", "Cocoa", "Ink", "Cream", "Gold", "Terracotta", "Tan", "Oat", "Stone", "Ivory", "Blue", "Clay", "Mocha", "Sienna"].map((item) => <option key={item}>{item}</option>)}</select></FilterGroup><FilterGroup label={`Price up to ${money(maxPrice)}`}><input type="range" min="10000" max="60000" step="2500" value={maxPrice} onChange={(event) => setMaxPrice(Number(event.target.value))} /></FilterGroup><div className="filter-note"><Sparkles size={15} /><p>Need help choosing? <button onClick={props.openStylist}>Ask our stylist</button></p></div></aside><div className="shop-results">{visibleProducts.length > 0 ? <div className="product-grid">{visibleProducts.map((product) => <ProductCard key={product.id} product={product} isWishlisted={props.wishlist.includes(product.id)} onWishlist={() => props.toggleWishlist(product.id)} onAdd={() => props.addToOrder(product)} onOrder={() => undefined} />)}</div> : <EmptyState title="Nothing here yet." text="Try a softer search or clear a filter — your next good outfit is probably close." onClick={clearFilters} />}</div></div></div>;
}

function FilterGroup({ label, children }: { label: string; children: ReactNode }) { return <div className="filter-group"><label className="eyebrow">{label}</label>{children}</div>; }

function ProductPage({ productId, ...props }: SharedProps & { productId: string }) {
  const product = getProduct(productId);
  usePageMeta(product ? `${product.name} | L&H Collective` : "Product not found | L&H Collective", product ? `${product.description} Shop ${product.name} from L&H Collective with easy WhatsApp ordering.` : "This L&H Collective product could not be found.");
  const [size, setSize] = useState(product?.sizes[0] || "");
  const [color, setColor] = useState(product?.colors[0] || "");
  const [zoom, setZoom] = useState(false);
  const [sizeGuide, setSizeGuide] = useState(false);
  const recommendations = product ? catalogProducts.filter((item) => item.category === product.category && item.id !== product.id).slice(0, 4) : [];
  if (!product) return <NotFoundPage />;
  return <div className="container product-page"><Link href="/shop" className="back-link"><ArrowLeft size={15} /> Back to shop</Link><div className="product-detail-layout"><div className="product-gallery"><button className={`gallery-main ${zoom ? "is-zoomed" : ""}`} onClick={() => setZoom(!zoom)} aria-label="Zoom product image"><img src={product.image} alt={product.alt} /></button><div className="gallery-hint">{zoom ? "Tap to reset" : "Tap image to zoom"}</div></div><div className="product-detail-copy"><p className="eyebrow">{product.category} / L&amp;H edit</p><h1>{product.name}</h1><p className="detail-price">{money(product.price)}</p><p className="detail-description">{product.description} Designed to go further, feel good, and earn its place in your weekly rotation.</p>{product.stock > 0 ? <p className="detail-stock"><span className="stock-dot" /> {product.stock <= 4 ? `Only ${product.stock} left` : "In stock and ready to ship"}</p> : <p className="detail-stock is-sold">Currently sold out — ask us to notify you on WhatsApp.</p>}<div className="selector-group"><div className="selector-heading"><span className="eyebrow">Size</span><button onClick={() => setSizeGuide(true)}>Size guide <ArrowUp size={13} /></button></div><div className="option-row">{product.sizes.map((item) => <button key={item} className={size === item ? "is-selected" : ""} onClick={() => setSize(item)}>{item}</button>)}</div></div><div className="selector-group"><span className="eyebrow">Colour: {color}</span><div className="color-row">{product.colors.map((item) => <button key={item} title={item} aria-label={`Choose ${item}`} className={`color-swatch color-${item.toLowerCase().replace(" ", "-")} ${color === item ? "is-selected" : ""}`} onClick={() => setColor(item)} />)}</div></div><div className="detail-actions"><a className={`button button-dark button-wide ${product.stock === 0 ? "is-muted-button" : ""}`} href={whatsappLink(product.stock === 0 ? `Hi! Please notify me when ${product.name} is back in stock.` : productMessage(product, size, color))} target="_blank" rel="noreferrer">{product.stock === 0 ? "Notify me on WhatsApp" : "Order on WhatsApp"} <MessageCircle size={17} /></a><button className="button button-outline button-wide" onClick={() => props.addToOrder(product, size, color)} disabled={product.stock === 0}>Add to order list <ShoppingBag size={17} /></button></div><div className="detail-trust"><span><Truck size={15} /> Local delivery available</span><span><MessageCircle size={15} /> Real-person fit help</span></div></div></div><div className="size-note"><Shirt size={19} /><p><strong>Not sure about the fit?</strong> Message us your usual size and measurements — we will help you choose before you order.</p><a href={whatsappLink(`Hi! I need fit help for ${product.name}.`)} target="_blank" rel="noreferrer">Ask on WhatsApp <ArrowRight size={14} /></a></div><Reveal className="section-block related-products"><SectionHeading eyebrow="Keep browsing" title="You may also like" actionLabel="View all" actionHref="/shop" /><div className="product-grid product-grid-four">{recommendations.map((item) => <ProductCard key={item.id} product={item} isWishlisted={props.wishlist.includes(item.id)} onWishlist={() => props.toggleWishlist(item.id)} onAdd={() => props.addToOrder(item)} onOrder={() => undefined} />)}</div></Reveal>{sizeGuide && <SizeGuide onClose={() => setSizeGuide(false)} />}</div>;
}

function SizeGuide({ onClose }: { onClose: () => void }) { return <div className="modal-backdrop" onClick={onClose}><div className="small-modal" onClick={(event) => event.stopPropagation()}><button className="modal-close" onClick={onClose} aria-label="Close size guide"><X size={18} /></button><p className="eyebrow">Find your fit</p><h2>Quick size guide</h2><p>Use your usual size as a starting point. For a relaxed look, size up. Need a second opinion? We are happy to help on WhatsApp.</p><table><tbody><tr><th>Size</th><th>Bust</th><th>Waist</th><th>Hip</th></tr><tr><td>S</td><td>34–35&quot;</td><td>27–28&quot;</td><td>37–38&quot;</td></tr><tr><td>M</td><td>36–37&quot;</td><td>29–30&quot;</td><td>39–40&quot;</td></tr><tr><td>L</td><td>38–40&quot;</td><td>31–33&quot;</td><td>41–43&quot;</td></tr><tr><td>XL</td><td>41–43&quot;</td><td>34–36&quot;</td><td>44–46&quot;</td></tr></tbody></table></div></div>; }

function CollectionsPage(props: SharedProps) {
  usePageMeta("Collections | L&H Collective", "Explore styled outfit sets and lookbook ideas from Lydia & Hannah Collective.");
  const looks = [{ title: "The soft power set", text: "Neutral layers, a little shine, and somewhere important to be.", image: "/assets/lookbook-neutral.jpg", products: ["lh-010", "lh-008"] }, { title: "Terracotta after five", text: "For dinner reservations, birthday plans, and the fun part of the week.", image: "/assets/hero-terracotta.jpg", products: ["lh-002", "lh-009"] }, { title: "Carry-all weekend", text: "A relaxed base, a roomy bag, and no need to overpack the mood.", image: "/assets/bag-neutral.jpg", products: ["lh-001", "lh-006"] }];
  return <div className="container page-shell collections-page"><div className="page-intro"><div><p className="eyebrow">The lookbook</p><h1>Get dressed<br /><em>in chapters.</em></h1></div><p>Start with a feeling. We will help with the rest.</p></div><div className="lookbook-list">{looks.map((look, index) => <Reveal key={look.title} className={`lookbook-row ${index % 2 ? "reverse" : ""}`}><div className="lookbook-row-image"><img src={look.image} alt={look.title} loading="lazy" /><span>0{index + 1}</span></div><div className="lookbook-row-copy"><p className="eyebrow">Look 0{index + 1}</p><h2>{look.title}</h2><p>{look.text}</p><div className="look-product-links">{look.products.map((id) => { const item = getProduct(id); return item ? <Link href={`/product/${item.id}`} key={id}>{item.name} <ArrowUp size={13} /></Link> : null; })}</div><Link href="/shop" className="button button-outline">Shop this look <ArrowRight size={16} /></Link></div></Reveal>)}</div><div className="stylist-banner"><div><p className="eyebrow">Still deciding?</p><h2>Tell us the occasion.<br /><em>We will style the rest.</em></h2></div><button className="button button-dark" onClick={props.openStylist}>Open AI stylist <Sparkles size={16} /></button></div></div>;
}

function AboutPage() { usePageMeta("About | L&H Collective", "Meet Lydia & Hannah Collective, a Lagos fashion brand for effortless, affordable everyday style."); return <div className="container page-shell about-page"><div className="page-intro"><div><p className="eyebrow">Our story</p><h1>Two friends.<br /><em>One very full wardrobe.</em></h1></div><p>L&amp;H Collective is for the woman who wants her clothes to keep up with her life.</p></div><div className="about-lead"><img src="/assets/editorial-neutral.jpg" alt="Editorial fashion scene from L&H Collective" /><div><p className="eyebrow">Why we started</p><p className="about-large-copy">Lydia and Hannah met over a shared love of getting dressed without making it a whole thing. After too many “where did you get that?” conversations, L&amp;H Collective became their answer: a thoughtful edit of easy pieces, honest prices, and a shopping experience that feels like a message to a stylish friend.</p><p>We believe good style is not a secret handshake. It is the right dress on a busy day, a bag that carries more than expected, and an outfit that gives you ten extra minutes of confidence when you need it.</p></div></div><div className="about-values"><div><p className="eyebrow">What we value</p><h2>Less noise.<br /><em>More good pieces.</em></h2></div><div className="about-value-list"><div><strong>Wearability first</strong><p>Every piece has to earn repeat wear — not just a first impression.</p></div><div><strong>Warm service</strong><p>We answer the WhatsApp message, help with fit, and keep things human.</p></div><div><strong>Style without stress</strong><p>Clear prices, local delivery, and a shop that meets you where you are.</p></div></div></div></div>; }

function ContactPage() { usePageMeta("Contact | L&H Collective", "Contact L&H Collective on WhatsApp, Instagram, or email for fit help, orders, and local delivery questions."); const [sent, setSent] = useState(false); const submit = (event: FormEvent<HTMLFormElement>) => { event.preventDefault(); const form = new FormData(event.currentTarget); const name = form.get("name"); const message = form.get("message"); setSent(true); window.open(whatsappLink(`Hi L&H Collective! My name is ${name}. ${message}`), "_blank", "noopener,noreferrer"); }; return <div className="container page-shell contact-page"><div className="page-intro"><div><p className="eyebrow">We are here</p><h1>Say hello.<br /><em>We reply.</em></h1></div><p>Questions about fit, delivery, or what to wear next? Send us a message and a real person will get back to you.</p></div><div className="contact-layout"><div className="contact-details"><a href={whatsappLink("Hi L&H Collective! I have a question.")} target="_blank" rel="noreferrer" className="contact-card"><MessageCircle size={21} /><span><small>WhatsApp</small><strong>{WHATSAPP_LABEL}</strong></span><ArrowUp size={15} /></a><a href="mailto:hello@lhcollective.ng" className="contact-card"><Mail size={21} /><span><small>Email</small><strong>hello@lhcollective.ng</strong></span><ArrowUp size={15} /></a><a href="https://instagram.com" target="_blank" rel="noreferrer" className="contact-card"><Instagram size={21} /><span><small>Instagram</small><strong>@lhcollective</strong></span><ArrowUp size={15} /></a><div className="contact-location"><MapPin size={18} /><div><small>Based in</small><strong>Lagos, Nigeria</strong><p>Local delivery support across Nigeria.</p></div></div></div><form className="contact-form" onSubmit={submit}><p className="eyebrow">Send a message</p><label>Your name<input name="name" required placeholder="Ada" /></label><label>Your email<input name="email" type="email" required placeholder="ada@email.com" /></label><label>How can we help?<textarea name="message" required rows={5} placeholder="Tell us what you are looking for..." /></label><button className="button button-dark" type="submit">{sent ? "Message opened" : "Continue to WhatsApp"} <Send size={15} /></button><p className="form-note">This form opens WhatsApp so your message goes straight to our team.</p></form></div></div>; }

function DeliveryPage() { usePageMeta("Delivery & Returns | L&H Collective", "Everything you need to know about L&H Collective delivery, exchanges, and returns in Nigeria."); const rows = [{ title: "Delivery", text: "We deliver across Nigeria. Once your order is confirmed on WhatsApp, we will share an estimated delivery window and fee based on your location." }, { title: "Free delivery", text: `Enjoy free delivery on orders over ${FREE_DELIVERY_THRESHOLD}. New drops and delivery updates are always shared on WhatsApp.` }, { title: "Exchanges", text: "If the fit is not quite right, message us within 48 hours of delivery. Items must be unworn, unwashed, and returned with original tags attached." }, { title: "Final sale", text: "Sale items and accessories are final sale unless they arrive damaged. We will always work with you to resolve a genuine product issue." }]; return <div className="container page-shell info-page"><div className="page-intro"><div><p className="eyebrow">Good to know</p><h1>Delivery &amp;<br /><em>returns.</em></h1></div><p>We keep the details clear so you can shop with confidence.</p></div><div className="info-list">{rows.map((row, index) => <div className="info-row" key={row.title}><span>0{index + 1}</span><h2>{row.title}</h2><p>{row.text}</p></div>)}</div><div className="info-cta"><Truck size={25} /><div><h2>Need a hand?</h2><p>Ask us anything before you order. We would rather help you choose well than make you guess.</p></div><a className="button button-dark" href={whatsappLink("Hi L&H Collective! I have a delivery or returns question.")} target="_blank" rel="noreferrer">Ask on WhatsApp <MessageCircle size={16} /></a></div></div>; }

function WishlistPage(props: SharedProps) { usePageMeta("Wishlist | L&H Collective", "Your saved L&H Collective pieces, ready whenever you are."); const [, setLocation] = useLocation(); const products = props.wishlist.map(getProduct).filter(Boolean) as Product[]; return <div className="container page-shell"><div className="page-intro"><div><p className="eyebrow">Saved for later</p><h1>Your wishlist.</h1></div><p>{products.length ? "The pieces you are thinking about. No pressure — they will be here when you are ready." : "Tap the heart on anything that catches your eye. Your future self will thank you."}</p></div>{products.length ? <div className="product-grid">{products.map((product) => <ProductCard key={product.id} product={product} isWishlisted onWishlist={() => props.toggleWishlist(product.id)} onAdd={() => props.addToOrder(product)} onOrder={() => undefined} />)}</div> : <EmptyState title="Nothing saved yet." text="Browse the shop and save the pieces you want to come back to." onClick={() => setLocation("/shop")} />}</div>; }

function EmptyState({ title, text, onClick }: { title: string; text: string; onClick: () => void }) { return <div className="empty-state"><Heart size={23} /><h2>{title}</h2><p>{text}</p><button className="button button-dark" onClick={onClick}>Shop the edit <ArrowRight size={15} /></button></div>; }

function NotFoundPage() { usePageMeta("Page not found | L&H Collective", "This L&H Collective page could not be found."); return <div className="container page-shell not-found"><p className="eyebrow">404 / Not found</p><h1>That page took<br /><em>a different route.</em></h1><p>Let us get you back to the good stuff.</p><Link href="/shop" className="button button-dark">Go to shop <ArrowRight size={16} /></Link></div>; }

function OrderDrawer({ orderList, onClose, removeFromOrder, updateQuantity, openStylist }: { orderList: OrderLine[]; onClose: () => void; removeFromOrder: (index: number) => void; updateQuantity: (index: number, delta: number) => void; openStylist: () => void }) {
  const lines = orderList.map((line) => { const product = getProduct(line.productId); return product ? { ...line, product } : null; }).filter(Boolean) as (OrderLine & { product: Product })[];
  const message = lines.length ? `Hi L&H Collective! I'd like to order:\n${lines.map((line) => `• ${line.product.name} — size ${line.size}, color ${line.color} x${line.quantity} — ${money(line.product.price * line.quantity)}`).join("\n")}\n\nPlease let me know the delivery total.` : "";
  return <div className="drawer-backdrop" onClick={onClose}><aside className="order-drawer" onClick={(event) => event.stopPropagation()} role="dialog" aria-modal="true" aria-labelledby="order-list-title"><div className="drawer-header"><div><p className="eyebrow">Your order list</p><h2 id="order-list-title">Ready when you are.</h2></div><button className="modal-close" onClick={onClose} aria-label="Close order list"><X size={18} /></button></div>{lines.length ? <><div className="drawer-lines">{lines.map((line, index) => <div className="drawer-line" key={`${line.product.id}-${index}`}><img src={line.product.image} alt="" /><div><strong>{line.product.name}</strong><span>{line.size} / {line.color} · {money(line.product.price)}</span><div className="drawer-quantity"><button onClick={() => updateQuantity(index, -1)} aria-label={`Decrease ${line.product.name} quantity`}><Minus size={13} /></button><span>Qty {line.quantity}</span><button onClick={() => updateQuantity(index, 1)} aria-label={`Increase ${line.product.name} quantity`}><Plus size={13} /></button></div><button onClick={() => removeFromOrder(index)}>Remove</button></div></div>)}</div><div className="drawer-total"><span>Items</span><strong>{lines.reduce((sum, line) => sum + line.quantity, 0)}</strong></div><a href={whatsappLink(message)} target="_blank" rel="noreferrer" className="button button-dark button-wide" onClick={onClose}>Send list on WhatsApp <MessageCircle size={16} /></a></> : <div className="drawer-empty"><ShoppingBag size={28} /><h3>Your list is empty.</h3><p>Add a few pieces and send everything to us at once.</p><Link href="/shop" className="button button-outline" onClick={onClose}>Browse the shop <ArrowRight size={15} /></Link></div>}<button className="drawer-stylist-link" onClick={() => { onClose(); openStylist(); }}><Sparkles size={15} /> Not sure what to add? Ask the stylist.</button></aside></div>;
}

function StylistModal({ onClose, onAdd, onOrder }: { onClose: () => void; onAdd: (product: Product) => void; onOrder: (product: Product) => void }) {
  const [occasion, setOccasion] = useState("");
  const [budget, setBudget] = useState("50000");
  const [style, setStyle] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const suggestions = useMemo(() => {
    if (!submitted) return [];
    const budgetNumber = Number(budget) || 50000;
    return sampleProducts.map((product) => {
      let score = product.price <= budgetNumber ? 2 : -2;
      const words = `${occasion} ${style}`.toLowerCase();
      product.tags.forEach((tag) => { if (words.includes(tag)) score += 3; });
      if (product.isBestSeller) score += 1;
      return { product, score };
    }).sort((a, b) => b.score - a.score).slice(0, 3).map((item) => item.product);
  }, [submitted, occasion, budget, style]);
  return <div className="modal-backdrop stylist-backdrop" onClick={onClose}><div className="stylist-modal" onClick={(event) => event.stopPropagation()}><button className="modal-close" onClick={onClose} aria-label="Close stylist"><X size={18} /></button><div className="stylist-header"><div className="stylist-sparkle"><Sparkles size={19} /></div><div><p className="eyebrow">L&amp;H AI stylist</p><h2>A good look starts<br /><em>with a little context.</em></h2></div></div>{!submitted ? <form className="stylist-form" onSubmit={(event) => { event.preventDefault(); setSubmitted(true); }}><label>What are you dressing for?<input required value={occasion} onChange={(event) => setOccasion(event.target.value)} placeholder="Brunch, a date, a work trip..." /></label><label>What is your budget?<div className="input-with-prefix"><span>₦</span><input type="number" min="5000" step="1000" required value={budget} onChange={(event) => setBudget(event.target.value)} /></div></label><label>What is your style mood?<input required value={style} onChange={(event) => setStyle(event.target.value)} placeholder="Soft, minimal, bold, relaxed..." /></label><button className="button button-dark button-wide" type="submit">Find my look <Sparkles size={16} /></button></form> : <div className="stylist-results"><div className="stylist-result-intro"><p>For a <strong>{occasion.toLowerCase()}</strong> moment with a <strong>{style.toLowerCase()}</strong> feel.</p><button onClick={() => setSubmitted(false)}>Start over</button></div>{suggestions.map((product) => <div className="stylist-product" key={product.id}><img src={product.image} alt={product.alt} /><div><p className="eyebrow">{product.category}</p><strong>{product.name}</strong><span>{money(product.price)}</span></div><button className="stylist-order" onClick={() => onOrder(product)} aria-label={`Order ${product.name} on WhatsApp`}><MessageCircle size={16} /></button><button className="stylist-add" onClick={() => onAdd(product)} aria-label={`Add ${product.name} to order list`}><Plus size={16} /></button></div>)}<p className="stylist-footnote"><Check size={14} /> Tap the chat icon to order, or add a piece to your list.</p></div>}</div></div>;
}

function App() {
  const [wishlist, setWishlist] = useState<string[]>(() => { try { return JSON.parse(localStorage.getItem("lh-wishlist") || "[]"); } catch { return []; } });
  const [orderList, setOrderList] = useState<OrderLine[]>(() => { try { return JSON.parse(localStorage.getItem("lh-order-list") || "[]"); } catch { return []; } });
  const [orderOpen, setOrderOpen] = useState(false);
  const [stylistOpen, setStylistOpen] = useState(false);
  useEffect(() => { localStorage.setItem("lh-wishlist", JSON.stringify(wishlist)); }, [wishlist]);
  useEffect(() => { localStorage.setItem("lh-order-list", JSON.stringify(orderList)); }, [orderList]);

  const toggleWishlist = (productId: string) => setWishlist((current) => current.includes(productId) ? current.filter((id) => id !== productId) : [...current, productId]);
  const addToOrder = (product: Product, size = product.sizes[0], color = product.colors[0]) => setOrderList((current) => { const existing = current.find((line) => line.productId === product.id && line.size === size && line.color === color); if (existing) return current.map((line) => line === existing ? { ...line, quantity: line.quantity + 1 } : line); return [...current, { productId: product.id, size, color, quantity: 1 }]; });
  const removeFromOrder = (index: number) => setOrderList((current) => current.filter((_, itemIndex) => itemIndex !== index));
  const updateOrderQuantity = (index: number, delta: number) => setOrderList((current) => current.flatMap((line, itemIndex) => itemIndex === index ? (line.quantity + delta > 0 ? [{ ...line, quantity: line.quantity + delta }] : []) : [line]));
  const orderProduct = (product: Product) => window.open(whatsappLink(productMessage(product)), "_blank", "noopener,noreferrer");

  const shared = { wishlist, toggleWishlist, orderList, addToOrder, removeFromOrder, openOrderList: () => setOrderOpen(true), openStylist: () => setStylistOpen(true) } satisfies SharedProps;

  return <Shell wishlist={wishlist} orderCount={orderList.reduce((sum, item) => sum + item.quantity, 0)} openOrderList={() => setOrderOpen(true)} openStylist={() => setStylistOpen(true)}><Switch><Route path="/" component={() => <HomePage {...shared} />} /><Route path="/shop" component={() => <ShopPage {...shared} />} /><Route path="/product/:id">{(params) => <ProductPage {...shared} productId={params.id} />}</Route><Route path="/collections" component={() => <CollectionsPage {...shared} />} /><Route path="/about" component={AboutPage} /><Route path="/contact" component={ContactPage} /><Route path="/delivery" component={DeliveryPage} /><Route path="/wishlist" component={() => <WishlistPage {...shared} />} /><Route component={NotFoundPage} /></Switch>{orderOpen && <OrderDrawer orderList={orderList} onClose={() => setOrderOpen(false)} removeFromOrder={removeFromOrder} updateQuantity={updateOrderQuantity} openStylist={() => setStylistOpen(true)} />}{stylistOpen && <StylistModal onClose={() => setStylistOpen(false)} onAdd={(product) => { addToOrder(product); setStylistOpen(false); setOrderOpen(true); }} onOrder={orderProduct} />}</Shell>;
}

export default App;
