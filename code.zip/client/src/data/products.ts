export type Category = "Clothing" | "Bags" | "Accessories";

export type Product = {
  id: string;
  name: string;
  category: Category;
  price: number;
  image: string;
  alt: string;
  description: string;
  sizes: string[];
  colors: string[];
  stock: number;
  isNew?: boolean;
  isBestSeller?: boolean;
  isSale?: boolean;
  tags: string[];
};

const unsplash = (id: string) =>
  `https://images.unsplash.com/${id}?auto=format&fit=crop&w=900&q=82`;

/**
 * Edit this list to add or update products. The shop demo below derives 60 cards
 * from these 12 sample records so the filters and ordering experience feel real.
 */
export const sampleProducts: Product[] = [
  {
    id: "lh-001",
    name: "Sunday Ease Set",
    category: "Clothing",
    price: 42000,
    image: unsplash("photo-1529139574466-a303027c1d8b"),
    alt: "Woman in a relaxed neutral two-piece outfit",
    description: "A breathable two-piece that does the most with the least effort.",
    sizes: ["S", "M", "L", "XL"],
    colors: ["Sand", "Black"],
    stock: 8,
    isNew: true,
    isBestSeller: true,
    tags: ["casual", "weekend", "brunch", "neutral", "comfortable"],
  },
  {
    id: "lh-002",
    name: "Sienna Slip Dress",
    category: "Clothing",
    price: 38500,
    image: "/assets/hero-terracotta.jpg",
    alt: "Terracotta draped dress in editorial light",
    description: "An easy, flattering slip with just enough drama for after-hours.",
    sizes: ["S", "M", "L"],
    colors: ["Sienna", "Cocoa"],
    stock: 4,
    isNew: true,
    tags: ["date night", "dinner", "occasion", "terracotta", "feminine"],
  },
  {
    id: "lh-003",
    name: "Everyday Column Skirt",
    category: "Clothing",
    price: 29500,
    image: unsplash("photo-1496747611176-843222e1e57c"),
    alt: "Woman styling a clean everyday skirt look",
    description: "A clean-lined midi that makes a tee feel instantly considered.",
    sizes: ["S", "M", "L", "XL"],
    colors: ["Ink", "Oat"],
    stock: 11,
    isBestSeller: true,
    tags: ["work", "casual", "minimal", "midi", "day"],
  },
  {
    id: "lh-004",
    name: "Soft Tailored Shirt",
    category: "Clothing",
    price: 26000,
    image: unsplash("photo-1521572163474-6864f9cf17ab"),
    alt: "Crisp soft-white shirt on a fashion rack",
    description: "The polished layer your jeans, skirts, and carry-on have been waiting for.",
    sizes: ["S", "M", "L", "XL"],
    colors: ["Ivory", "Blue"],
    stock: 0,
    isSale: true,
    tags: ["work", "layering", "travel", "classic", "office"],
  },
  {
    id: "lh-005",
    name: "Ribbed Day Tank",
    category: "Clothing",
    price: 14500,
    image: unsplash("photo-1509631179647-0177331693ae"),
    alt: "Minimal ribbed tank styled with neutral tailoring",
    description: "A soft, close-to-body essential for hot days and easy layers.",
    sizes: ["S", "M", "L"],
    colors: ["Cream", "Black", "Clay"],
    stock: 16,
    isNew: true,
    tags: ["casual", "basics", "hot day", "layering", "everyday"],
  },
  {
    id: "lh-006",
    name: "The Soft Carryall",
    category: "Bags",
    price: 33000,
    image: "/assets/bag-neutral.jpg",
    alt: "Soft cream leather carryall bag",
    description: "A roomy everyday carryall with a quiet, go-anywhere shape.",
    sizes: ["One size"],
    colors: ["Cream", "Tan"],
    stock: 6,
    isBestSeller: true,
    tags: ["work", "travel", "everyday", "bag", "neutral"],
  },
  {
    id: "lh-007",
    name: "Mini Crossbody Mood",
    category: "Bags",
    price: 24000,
    image: unsplash("photo-1548036328-c9fa89d128fa"),
    alt: "Small crossbody bag in a warm neutral shade",
    description: "Hands-free, surprisingly roomy, and ready for plans that run late.",
    sizes: ["One size"],
    colors: ["Cocoa", "Black"],
    stock: 2,
    isNew: true,
    tags: ["date night", "weekend", "crossbody", "night out"],
  },
  {
    id: "lh-008",
    name: "Sculpted Hoop Pair",
    category: "Accessories",
    price: 9500,
    image: unsplash("photo-1539109136881-3be0616acf4b"),
    alt: "Gold sculpted hoop earrings with an editorial outfit",
    description: "A little shine that makes a simple look feel fully finished.",
    sizes: ["One size"],
    colors: ["Gold"],
    stock: 13,
    isBestSeller: true,
    tags: ["gift", "gold", "occasion", "minimal", "jewellery"],
  },
  {
    id: "lh-009",
    name: "Terracotta Silk Scarf",
    category: "Accessories",
    price: 12000,
    image: "/assets/editorial-neutral.jpg",
    alt: "Warm terracotta scarf styled with neutral fashion",
    description: "A soft color note for your hair, neck, bag handle, or next great photo.",
    sizes: ["One size"],
    colors: ["Terracotta", "Sand"],
    stock: 9,
    isNew: true,
    tags: ["gift", "terracotta", "travel", "styling", "accessory"],
  },
  {
    id: "lh-010",
    name: "Ease Knit Cardigan",
    category: "Clothing",
    price: 31000,
    image: "/assets/lookbook-neutral.jpg",
    alt: "Light neutral cardigan styled over a flowing outfit",
    description: "A light layer that keeps air-conditioning and overthinking at bay.",
    sizes: ["S", "M", "L"],
    colors: ["Oat", "Mocha"],
    stock: 5,
    tags: ["layering", "travel", "work", "cozy", "neutral"],
  },
  {
    id: "lh-011",
    name: "Weekend Wide-Leg Trouser",
    category: "Clothing",
    price: 35500,
    image: unsplash("photo-1485968579580-b6d095142e6e"),
    alt: "Woman in wide-leg trousers on a city street",
    description: "High-waisted, easy-moving, and made for the long way home.",
    sizes: ["S", "M", "L", "XL"],
    colors: ["Stone", "Black"],
    stock: 7,
    isBestSeller: true,
    tags: ["work", "weekend", "travel", "tailored", "comfortable"],
  },
  {
    id: "lh-012",
    name: "Sunday Flat Mules",
    category: "Accessories",
    price: 27000,
    image: unsplash("photo-1490481651871-ab68de25d43d"),
    alt: "Neutral flat mule shoes styled with a soft outfit",
    description: "The throw-on pair that makes every outfit look more deliberate.",
    sizes: ["37", "38", "39", "40", "41"],
    colors: ["Tan", "Black"],
    stock: 0,
    isSale: true,
    tags: ["work", "everyday", "shoes", "minimal", "walkable"],
  },
];

const variantNames = ["Edit", "Studio", "Afterglow", "Weekend", "City", "Limited"];

export const catalogProducts: Product[] = [
  ...sampleProducts,
  ...Array.from({ length: 48 }, (_, index) => {
    const base = sampleProducts[index % sampleProducts.length];
    const variation = variantNames[index % variantNames.length];
    return {
      ...base,
      id: `${base.id}-v${index + 1}`,
      name: `${base.name} — ${variation}`,
      price: base.price + ((index % 4) - 1) * 1500,
      stock: Math.max(0, base.stock - (index % 5)),
      isNew: index % 3 === 0,
      isBestSeller: index % 7 === 0,
      isSale: index % 11 === 0,
    };
  }),
];

export const getProduct = (id: string) => catalogProducts.find((product) => product.id === id);
