export default {
  logoUrl: "https://files.manuscdn.com/search-media/310519663897023145/UTcnGQEakVXvCdRqheRUu3/fMbj9fJh649BSRDVWsAMUi.jpg",
};
