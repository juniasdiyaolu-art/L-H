# L&H Collective — implementation plan

## Product approach

Build a fast, mobile-first fashion storefront for Lydia & Hannah Collective. The site is intentionally WhatsApp-first: no online checkout, no payment flow, and no account creation. Product data lives in one editable TypeScript file. The browser owns wishlist and order-list state through localStorage. WhatsApp links are generated from the selected product, size, color, and current order list.

The starter is a static React/Vite site because the brief does not require a server or database. The AI Stylist is implemented as a fast in-browser recommendation assistant: it asks for occasion, budget, and style, scores the editable product catalog, and returns clickable suggestions with WhatsApp actions. This keeps the experience functional without adding latency or credentials.

## Design direction

### Alternative styles considered

- Lagos soft-luxe editorial — 0.08 probability; warm neutrals, confident serif display type, and magazine-like spacing.
- Playful market-day color pop — 0.06 probability; bright color blocks, sticker-like labels, and bolder sans typography.
- Quiet coastal minimal — 0.04 probability; pale sand, airy whitespace, and restrained product storytelling.

### Chosen style: Lagos soft-luxe editorial

- **Design Movement:** Contemporary African boutique editorial with a relaxed, resort-inspired polish.
- **Core Principles:** tactile warmth, confident simplicity, generous breathing room, and useful micro-interactions.
- **Color Philosophy:** cream and ink make the shop feel calm and premium; terracotta supplies a recognizable, human warmth that feels sun-baked and local without turning the brand loud.
- **Layout Paradigm:** editorial magazine flow — oversized image-led moments, offset text blocks, horizontal rails, and asymmetric split sections instead of a uniform dashboard grid.
- **Signature Elements:** a terracotta announcement strip, oversized serif headlines with small uppercase eyebrow labels, and pill-shaped WhatsApp actions paired with thin outlined controls.
- **Interaction Philosophy:** every interaction should make shopping feel lighter: filters are immediate, wishlist hearts are optimistic, order actions are explicit, and motion is short and soft.
- **Animation:** 150–350ms fades and lifts, subtle image zoom on hover, one gentle pulse for the floating WhatsApp button, and reduced-motion fallbacks.
- **Typography System:** Cormorant Garamond for headlines and the wordmark; Inter for navigation, controls, prices, and body copy. Headings are high-contrast and compact; body copy is 14–16px with relaxed line height.
- **Brand Essence:** effortless Lagos style for women who want good pieces without the hard sell — warm, assured, practical.
- **Brand Voice:** friendly, confident, and benefit-led. Example lines: “Easy pieces. Big outfit energy.” and “Tell us the look. We’ll meet you on WhatsApp.”
- **Wordmark & Logo:** a stacked “L&H” ligature mark beside a narrow serif wordmark, with the ampersand acting as the visual signature.
- **Signature Brand Color:** sun-baked terracotta `#B95E45`.

## Application structure

- `client/src/data/products.ts`: 12 editable sample product records plus derived shop variants to demonstrate a 50+ item catalog without duplicating source data.
- `client/src/App.tsx`: route switch, shared shell, home/shop/product/collections/about/contact/delivery/wishlist/not-found views, WhatsApp composer, wishlist/order-list state, filters, and stylist modal.
- `client/src/index.css`: brand tokens, typography, responsive layout, editorial section primitives, motion, and accessibility states.
- `client/public/assets/`: locally stored placeholder editorial images selected for hero, lookbook, accessories, and Instagram-style moments.
- `client/public/manus-routes.json`: declared public route set for the preview/runtime route manifest.
- `client/public/sitemap.xml` and `client/public/robots.txt`: basic crawl documents for the public static site.
- `client/index.html`: document-level title, description, and social metadata baseline.
- `app.config.ts`: project logo metadata for the Manus project shell.

## Feature mapping

The Home route includes the sticky navigation, hero, category tiles, featured products, best sellers rail, shop-the-look section, benefits, reviews carousel, social grid, signup panel, footer, floating WhatsApp button, back-to-top affordance, and stylist launch point. Shop includes search, category/size/color/price filters, sorting, 50+ derived catalog cards, wishlist actions, and add-to-order actions. Product detail supports gallery, zoom state, size/color selection, size guide dialog, stock states, recommendations, and the exact prefilled WhatsApp message format. Collections, About, Contact, Delivery & Returns, Wishlist, and 404 routes are all linked in the shell.

All customer-facing WhatsApp links use a clearly marked placeholder number in one constant so the owner can replace it once. The announcement bar likewise keeps the free-delivery threshold in one constant. The contact form is intentionally lightweight and opens WhatsApp with the submitted message rather than pretending to send email.

## Serving and delivery

Run the static Vite development server on port 3000 with `pnpm dev:static`. Use `pnpm check` for TypeScript diagnostics and `pnpm build:static` for the static production bundle. The project remains server- and database-free until the brand later needs inventory management, customer accounts, or a real AI provider.
